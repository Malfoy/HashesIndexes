
#include <algorithm>
#include <array>
#include <chrono>
#include <cstring>
#include <string>
#include <fstream>
#include <functional>
#include <iostream>
#include <mutex>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <math.h>
#include <cassert>
#include "NaiveIndex.h"
#include "EvaluationMaker.h"
#include "TestTable.h"






int main(int argc, char** argv)
{
        //time
        std::chrono::time_point<std::chrono::system_clock> start, end, startDB, endDB, startQuery, endQuery;
        start = std::chrono::system_clock::now();

        //create ComparisonMatrix
        ComparisonMatrix firstMatrix;


        //production of the (hash) Testtable
        string theFasta("160k250gen.fa");
        TestTable refTable;
        refTable.parse_fasta_for_refTable(theFasta);
        ifstream theFileQuery("read_50k_errorate5.fa");
        string oneGenome(refTable.get_line_fasta_for_testtable(&theFileQuery));
        vector<long double> TestResultVector(refTable.query_belonging_genome(oneGenome));
        vector<pair<long double,uint16>> sortedVectorTest(refTable.sort_scores(TestResultVector,0));
        refTable.show_sorted_scores(sortedVectorTest);
        firstMatrix.add_result_vector(TestResultVector);

        //production of the index(es)
        uint binaryPowerStart(10);
        for (uint binaryPower = binaryPowerStart; binaryPower < 23; binaryPower++) // 2" and > is too high for my cpu with 160kcarac250gen
        {
        string theFasta("160k250gen.fa");
        assert(pow(2,binaryPower) > pow(2,8) && (pow(2,binaryPower) < pow(2,30)));
        startDB = std::chrono::system_clock::now();
        NaiveIndex firstIndex(pow(2,binaryPower),256);//((bucketnumbers, binary decimal (2,4,8...1024...) for record))
        firstIndex.index_sequences_from_fasta(theFasta);
        endDB = std::chrono::system_clock::now();
        ifstream theFileQuery("read_50k_errorate5.fa");
        startQuery = std::chrono::system_clock::now();
        string oneGenome(firstIndex.get_line_fasta_for_naive(&theFileQuery));
        vector<long double> NaiveResultVector(firstIndex.query_sequence(oneGenome));
        endQuery = std::chrono::system_clock::now();
        vector<pair<long double,uint16>> sortedVector(firstIndex.sort_scores(NaiveResultVector,0));
        firstIndex.show_sorted_scores(sortedVector);
        firstMatrix.add_result_vector(NaiveResultVector);
        firstMatrix.fill_time((binaryPower - (binaryPowerStart-1)), endDB-startDB, endQuery-startQuery);
        cout << "binarypower" << binaryPower << endl;
        }
        cout << "step0" << endl;

        //The comparison
        firstMatrix.create_comparison();
        cout << "step1" << endl;
        firstMatrix.show_the_matrix();
        cout << "step2" << endl;

        //the record chosen
        firstMatrix.write_result("invers_results.csv", "jaccardBucketsNumberdifference(col_inversion)", 1);
        cout << "step3" << endl;

        end = std::chrono::system_clock::now();
        std::chrono::duration<double> elapsedTime(end - start);
        cout << endl << elapsedTime.count() << " sec" << endl;
        cout << "step4" << endl;

        return 0;
}
