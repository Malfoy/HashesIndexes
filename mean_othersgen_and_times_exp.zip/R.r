library("tidyverse")

results = read.csv("manual_results.csv")

selectedresults <- gather(data = results, key = Legend, value = VAL, TargetGenome, MeanOthersGenomes, MaxOthersGenomes)

ggplot(selectedresults, aes(x = Bucket_Number_with_pow_2, y = VAL, color = Legend)) +
  geom_line() +
  geom_hline(yintercept=0.302, size=0.25, color="firebrick") +
  labs(
        x="Bits (for 2 ^ bits Buckets number)",
        y="Jaccard Index",
        title="Precision of index table in function of buckets number",
        subtitle=" with the reference of the hashtable",
        caption="Experimental condition : 1 read of 50k nuc with 5% error, find among 250 genomes 160K nuc") +
  annotate (geom="text",x = 19, y = 0.295, label = "Ideal Jaccard Index", color="firebrick") +
  theme(legend.position=("bottom")) +
  scale_fill_discrete(name = "legend") 

ggsave("plot.png", width = 7, height = 7)
