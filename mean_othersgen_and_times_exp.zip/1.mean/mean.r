library("tidyverse")

results = read.csv("invers_results.csv")

resultsfiltered = filter(results, Genome != 3) 

mean = colMeans(resultsfiltered)

mean
