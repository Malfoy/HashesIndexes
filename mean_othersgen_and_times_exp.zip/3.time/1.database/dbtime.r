library("tidyverse")

results = read.csv("results.csv")

selectedresults = select(results, Bucket_Number_with_pow_2, time_for_database)

ggplot(selectedresults, aes(x = Bucket_Number_with_pow_2, y = time_for_database)) +
  geom_line(color="seagreen") +
  labs(
        x="Bits (for 2 ^ bits Buckets number)",
        y="Time (sec)",
        title="Time index building in function of buckets number",
        caption="Experimental condition : 250 genomes 160K nuc")
ggsave("timedbplot.png", width = 7, height = 7)
