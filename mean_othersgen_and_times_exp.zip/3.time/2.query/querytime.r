library("tidyverse")

results = read.csv("results.csv")

selectedresults = select(results, Bucket_Number_with_pow_2, time_for_query)

ggplot(selectedresults, aes(x = Bucket_Number_with_pow_2, y = time_for_query)) +
  geom_line(color="olivedrab") +
  labs(
        x="Bits (for 2 ^ bits Buckets number)",
        y="Time (sec)",
        title="Query search in index in function of buckets number",
        caption="Experimental condition : 1 read of 50k nuc with 5% error, find among 250 genomes 160K nuc")
ggsave("timequeryplot.png", width = 7, height = 7)
