library("tidyverse")

results_0 = read.csv("300reads_0ER.csv")
results_3 = read.csv("300reads_3ER.csv")
results_6 = read.csv("300reads_6ER.csv")

#selectedresults <- gather(data = results, key = Legend, value = VAL,tenb,fourteenb,eighteenb)


ggplot(results_3, aes(x = hashtable, y = three_error)) +
  geom_point(color = "sandybrown") +
  geom_abline()+
  labs(
        x="Jaccard Index from Hashtable",
        y="Jaccard Index from Index",
        title="Precision of index table in function of buckets number",
        subtitle=" with help of the hashtable jaccard index",
        caption="Experimental condition:300 reads of different k (6-18) nuc with 3% error, among 1000 genomes 30K nuc") +
  theme(legend.position=("bottom")) +
  scale_fill_discrete(name = "legend") 

ggsave("plot30k300ER3reads.png", width = 8, height = 8)
