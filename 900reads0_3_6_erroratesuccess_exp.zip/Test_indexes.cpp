#include <algorithm>
#include <array>
#include <chrono>
#include <cstring>
#include <string>
#include <fstream>
#include <functional>
#include <iostream>
#include <mutex>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <math.h>
#include <cassert>
#include "NaiveIndex.h"
#include "EvaluationMaker.h"
#include "TestTable.h"



int main(int argc, char** argv)
{
        //Begin csv
        ofstream myCsv;
        myCsv.open ("300reads_3ER.csv");
        myCsv << "hashtable,six_error"<< endl; //three_error,six_error"

        //create ComparisonMatrix
        ComparisonMatrix CMatrix;

        //production of the (hash) Testtable
        string theFasta("1000gen30kNuc.fa");
        TestTable refTable;
        refTable.parse_fasta_for_refTable(theFasta);
        string theRead("300reads_3ER.fa");
        vector<vector<long double>> bigUltimVector;// contains all score vector of all queries
        bigUltimVector = refTable.get_all_queries_scores_for_table(bigUltimVector,theRead);
        vector<int> testfirstGoodGenomeVector(refTable.get_good_genome_vector());//-2 for compare_good_genome; will be compare to indexfirstgood.. to verify the good best genome

        //production of the index(es)
        vector<NaiveIndex> vectorNaiveIndexes;
        vector<uint> binPow{15}; //binary power tested
        for (uint cursorForvectorNaiveIndexes = 0; cursorForvectorNaiveIndexes < (uint) binPow.size(); cursorForvectorNaiveIndexes++) //to browse in different binary power
        {
          NaiveIndex NewIndex(pow(2,binPow[cursorForvectorNaiveIndexes]),256);
          cout << "step1.1" << endl;
          NewIndex.index_sequences_from_fasta(theFasta);
          cout << "step1.2" << endl;
          bigUltimVector = NewIndex.get_all_queries_scores_for_index(bigUltimVector,theRead);
          vector<int> indexfirstGoodGenomeVector(NewIndex.get_good_genome_vector());
          CMatrix.compare_good_genome(testfirstGoodGenomeVector,indexfirstGoodGenomeVector);
          cout << "index " << cursorForvectorNaiveIndexes << " finish" << endl;
        }
        cout << "step2" << endl;

        //The comparison and the record
        uint queriesNumber(300);
        cout << "step3" << endl;
        for (uint cursor = 0; cursor < queriesNumber; cursor++)
        {
          cout << "step4" << endl;
          myCsv << CMatrix.get_other_string_from_ultim_vector(bigUltimVector, queriesNumber, cursor) << endl;
          cout << "line " << cursor << endl;
        }
        myCsv.close();
        return 0;
}
