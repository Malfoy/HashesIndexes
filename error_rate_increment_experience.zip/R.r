library("tidyverse")

results = read.csv("Error_Rate_Experiment.csv")

selectedresults <- gather(data = results, key = Legend, value = VAL,tenbTargetGenome,fifteenbTargetGenome,twentytwobTargetGenome,tenbestUnwantedGenome,fiftybestUnwantedGenome,twentytwobestUnwantedGenome)

ggplot(selectedresults, aes(x = VAL, y = hashtable, color = Legend)) +
  geom_point() +
  geom_abline()+
  labs(
        x="Jaccard Index from Index",
        y="Jaccard Index from Hashtable",
        title="Precision of index table in function of buckets number",
        subtitle=" in contrast with unwanted genomes",
        caption="Experimental condition : 10 read of 50k nuc with ++ 10% error, from one genome among 250 genomes 160K nuc") +
  theme(legend.position=("bottom")) +
  scale_fill_discrete(name = "legend") 

ggsave("plot.png", width = 7, height = 7)
