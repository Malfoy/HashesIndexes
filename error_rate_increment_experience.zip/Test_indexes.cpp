#include <algorithm>
#include <array>
#include <chrono>
#include <cstring>
#include <string>
#include <fstream>
#include <functional>
#include <iostream>
#include <mutex>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <math.h>
#include <cassert>
#include "NaiveIndex.h"
#include "EvaluationMaker.h"
#include "TestTable.h"



int main(int argc, char** argv)
{
        //Begin csv
        ofstream myCsv;
        myCsv.open ("Error_Rate_Experiment.csv");
        myCsv << "hashtable,tenbTargetGenome,fifteenbTargetGenome,twentytwobTargetGenome,tenbestUnwantedGenome,fiftybestUnwantedGenome,twentytwobestUnwantedGenome" << endl;

        //create ComparisonMatrix
        vector<ComparisonMatrix> MaMaMatrix(10);
        vector<string> myErrorRateList{"read_50k_errorexp_0.fa", "read_50k_errorexp_10.fa", "read_50k_errorexp_20.fa", "read_50k_errorexp_30.fa", "read_50k_errorexp_40.fa", "read_50k_errorexp_50.fa", "read_50k_errorexp_60.fa", "read_50k_errorexp_70.fa", "read_50k_errorexp_80.fa", "read_50k_errorexp_90.fa"};

        //production of the (hash) Testtable and fill begin of every matrix in MaMaMatrix
        string theFasta("160k250gen.fa");
        TestTable refTable;
        refTable.parse_fasta_for_refTable(theFasta);
        for (uint cursorMaMaMatrix = 0; cursorMaMaMatrix < 10; cursorMaMaMatrix++)
        {
          vector<long double> goodVector;
          ifstream theFileQuery(myErrorRateList[cursorMaMaMatrix]);
          string oneGenome(refTable.get_line_fasta_for_testtable(&theFileQuery));
          vector<long double> TestResultVector(refTable.query_belonging_genome(oneGenome));
          vector<pair<long double,uint16>> sortedVectorTest(refTable.sort_scores(TestResultVector,0));
          refTable.show_sorted_scores(sortedVectorTest);
          for(uint position = 0; position < sortedVectorTest.size(); position++)
          {
            goodVector.push_back(sortedVectorTest[position].first);
          }
          MaMaMatrix[cursorMaMaMatrix].add_result_vector(goodVector);
        }

        //production of the index(es)
        vector<NaiveIndex> vectorNaiveIndexes;
        vector<uint> binPow{10, 15, 20}; //binary power that we test
        for (uint cursorForvectorNaiveIndexes = 0; cursorForvectorNaiveIndexes < 3; cursorForvectorNaiveIndexes++) //to browse in different binary power
        {
          NaiveIndex NewIndex(pow(2,binPow[cursorForvectorNaiveIndexes]),256);
          vectorNaiveIndexes.push_back(NewIndex);
          vectorNaiveIndexes[cursorForvectorNaiveIndexes].index_sequences_from_fasta(theFasta);
          for (uint cursorErrorRateList = 0; cursorErrorRateList < 10; cursorErrorRateList++)
          {
            vector<long double> finalVector;
            ifstream theFileQuery(myErrorRateList[cursorErrorRateList]);
            string oneGenome(vectorNaiveIndexes[cursorForvectorNaiveIndexes].get_line_fasta_for_naive(&theFileQuery));
            vector<long double> NaiveResultVector(vectorNaiveIndexes[cursorForvectorNaiveIndexes].query_sequence(oneGenome));
            vector<pair<long double,uint16>> sortedVector(vectorNaiveIndexes[cursorForvectorNaiveIndexes].sort_scores(NaiveResultVector,0));
            vectorNaiveIndexes[cursorForvectorNaiveIndexes].show_sorted_scores(sortedVector,3);
            for(uint position = 0; position < sortedVector.size(); position++)
            {
              finalVector.push_back(sortedVector[position].first);
            }
            MaMaMatrix[cursorErrorRateList].add_result_vector(finalVector);
            cout << "index:" << cursorForvectorNaiveIndexes << " read:" <<  cursorErrorRateList << endl;
          }
        }
        cout << "step0" << endl;

        //The comparison and the record
        for (uint cursorMaMaMatrix = 0; cursorMaMaMatrix < 10; cursorMaMaMatrix++)
        {
          MaMaMatrix[cursorMaMaMatrix].create_comparison();
          cout << "step1 cursorMaMaMatrix " << cursorMaMaMatrix << endl;
          MaMaMatrix[cursorMaMaMatrix].show_the_matrix();
          cout << "step2 cursorMaMaMatrix " << cursorMaMaMatrix << endl;
          myCsv << MaMaMatrix[cursorMaMaMatrix].get_string_two_best_JacInd() << endl;
          cout << "step3 cursorMaMaMatrix " << cursorMaMaMatrix << endl;
        }
        myCsv.close();
        return 0;
}
