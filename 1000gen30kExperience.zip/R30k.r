library("tidyverse")

results = read.csv("1000gen30kNuc.csv")

selectedresults <- gather(data = results, key = Legend, value = VAL,tenb,fifteenb,twentytwob)

ggplot(selectedresults, aes(x =hashtable, y = VAL, color = Legend)) +
  geom_point() +
  geom_abline()+
  labs(
        x="Jaccard Index from Hashtable",
        y="Jaccard Index from Index",
        title="Precision of index table in function of buckets number",
        subtitle=" with help of the hashtable jaccard index",
        caption="Experimental condition : 700 good reads of different k (6-24) nuc with + 5% error, from one genome among 1000 genomes 30K nuc") +
  theme(legend.position=("bottom")) +
  scale_fill_discrete(name = "legend") 

ggsave("plot.png", width = 7, height = 7)
